import React from 'react'
export default function Topbar(){return(<div className='flex flex-col md:flex-row items-start md:items-center justify-between gap-3'>
  <div><h1 className='text-xl md:text-2xl font-bold'>IBM Quantum Jobs Tracker</h1><p className='text-white/60 text-sm'>Modern, dark, and delightfully animated dashboard</p></div>
  <div className='flex items-center gap-3 no-print'><a href='https://github.com' target='_blank' className='btn-ghost'>⭐ Star</a><button className='btn-primary' onClick={()=>window.print()}>Download Report (PDF)</button></div>
</div>)}