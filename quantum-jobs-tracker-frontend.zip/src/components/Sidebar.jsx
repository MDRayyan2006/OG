import React from 'react'
import { NavLink } from 'react-router-dom'
import { clsx } from 'clsx'
const NavItem=({to,label,icon})=>(
  <NavLink to={to} className={({isActive})=>clsx('group flex items-center gap-3 px-3 py-2 rounded-xl transition-all',isActive?'bg-white/10 border border-white/15 shadow-glow':'hover:bg-white/5 border border-transparent')}>
    <span className='text-2xl'>{icon}</span><span className='font-medium'>{label}</span><span className='ml-auto opacity-0 group-hover:opacity-100 transition-opacity text-soft'>→</span>
  </NavLink>)
export default function Sidebar(){
  return(<div className='flex flex-col gap-6'>
    <div className='flex items-center gap-3'><div className='h-10 w-10 rounded-2xl bg-gradient-to-br from-accent to-accent2 flex items-center justify-center animate-floaty'>⚛️</div><div><div className='font-extrabold tracking-wide'>Quantum Jobs Tracker</div><div className='text-xs text-white/60'>with User Insights</div></div></div>
    <nav className='flex flex-col gap-2'>
      <NavItem to='/dashboard' label='Dashboard' icon='🏠'/>
      <NavItem to='/jobs' label='Job Recommendations' icon='💼'/>
      <NavItem to='/test' label='Take a Test' icon='🧪'/>
      <NavItem to='/history' label='Test History' icon='📈'/>
      <NavItem to='/upgrade' label='Upgrade Me' icon='🚀'/>
      <NavItem to='/profile' label='Profile Overview' icon='👤'/>
    </nav>
    <div className='mt-2 text-xs text-white/50'><div>Theme: Dark</div><div>Hackathon Demo Ready ✅</div></div>
  </div>)}
