import React from 'react'
import { Bar } from 'react-chartjs-2'
import { Chart, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js'
Chart.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend)
export default function TechBarChart({techs=[]}){const labels=techs;const counts=techs.map(()=>1);const data={labels,datasets:[{label:'Tech Stack Mentions',data:counts}]};const opts={responsive:true,plugins:{legend:{display:false},tooltip:{mode:'index',intersect:false}},scales:{x:{ticks:{color:'#cbd5e1'},grid:{color:'rgba(255,255,255,0.06)'}},y:{ticks:{color:'#cbd5e1'},grid:{color:'rgba(255,255,255,0.06)'}}}};return(<div className='glass p-4'><Bar data={data} options={opts}/></div>)}