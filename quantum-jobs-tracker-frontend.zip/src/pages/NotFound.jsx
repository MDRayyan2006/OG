import React from 'react'
export default function NotFound(){return(<div className='text-white/60'>Page not found.</div>)}
