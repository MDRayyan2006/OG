import React,{useEffect,useState} from 'react'
import PageHeader from '../components/PageHeader.jsx'
import StatCard from '../components/StatCard.jsx'
import { profileOverview } from '../api.js'
const UID='demo-user'
export default function ProfileOverview(){const [overview,setOverview]=useState(null);const [loading,setLoading]=useState(true);const [error,setError]=useState(null);
useEffect(()=>{(async()=>{try{const res=await profileOverview(UID);setOverview(res)}catch(e){setError(e.message)}finally{setLoading(false)}})()},[])
return(<div className='space-y-6'><PageHeader title='Profile Overview' subtitle='Your resume, jobs, and tests at a glance.'/>{loading&&<div>Loading…</div>}{error&&<div className='text-rose-400'>Failed: {error}</div>}{overview&&(<><div className='grid grid-cols-1 md:grid-cols-3 gap-4'><StatCard label='Resume Strength' value={(overview.resume?.strength_score||0).toFixed(1)+'/10'}/><StatCard label='Available Jobs' value={overview.available_jobs||0}/><StatCard label='Avg Test Score' value={(overview.test_performance?.average_score||0).toFixed(1)+'%'}/></div><div className='glass p-4'><div className='text-sm text-white/60 mb-2'>Last Test Score</div><div className='text-2xl font-bold'>{(overview.test_performance?.last_score||0).toFixed(1)}%</div></div></>)}</div>)}
