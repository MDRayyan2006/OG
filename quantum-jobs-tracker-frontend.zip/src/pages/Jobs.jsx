import React,{useEffect,useState} from 'react'
import PageHeader from '../components/PageHeader.jsx'
import JobCard from '../components/JobCard.jsx'
import { getJobRecommendations } from '../api.js'
const UID='demo-user'
export default function Jobs(){const [recs,setRecs]=useState([]);const [loading,setLoading]=useState(true);const [error,setError]=useState(null);
useEffect(()=>{(async()=>{try{const data=await getJobRecommendations(UID);setRecs(data.recommendations||[])}catch(e){setError(e.message)}finally{setLoading(false)}})()},[])
return(<div className='space-y-6'><PageHeader title='Job Recommendations' subtitle='Top matches based on your resume.'/>{loading&&<div>Loading…</div>}{error&&<div className='text-rose-400'>Failed: {error}</div>}<div className='grid grid-cols-1 md:grid-cols-2 gap-4'>{recs.map(r=>(<JobCard key={r.job_id} job={r} onApply={()=>alert('Demo: apply clicked')}/>))}{!loading&&recs.length===0&&<div className='text-white/60'>No recommendations yet. Upload a resume on Dashboard.</div>}</div></div>)}