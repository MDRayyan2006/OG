import React,{useEffect,useState} from 'react'
import PageHeader from '../components/PageHeader.jsx'
import StatCard from '../components/StatCard.jsx'
import { Line } from 'react-chartjs-2'
import { Chart, LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend } from 'chart.js'
import { getTestHistory } from '../api.js'
Chart.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend)
const UID='demo-user'
export default function TestHistory(){const [data,setData]=useState(null);const [loading,setLoading]=useState(true);const [error,setError]=useState(null);
useEffect(()=>{(async()=>{try{const res=await getTestHistory(UID);setData(res)}catch(e){setError(e.message)}finally{setLoading(false)}})()},[])
const labels=(data?.test_history||[]).map(r=>new Date(r.timestamp).toLocaleString());const scores=(data?.test_history||[]).map(r=>r.total_score);const chartData={labels,datasets:[{label:'Score',data:scores}]};const opts={responsive:true,plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#cbd5e1'},grid:{color:'rgba(255,255,255,0.06)'}},y:{ticks:{color:'#cbd5e1'},grid:{color:'rgba(255,255,255,0.06)'}}}};
return(<div className='space-y-6'><PageHeader title='Test History' subtitle='Scores over time and quick analytics.'/>{loading&&<div>Loading…</div>}{error&&<div className='text-rose-400'>Failed: {error}</div>}{data&&(<><div className='grid grid-cols-1 md:grid-cols-3 gap-4'><StatCard label='Average Score' value={`${(data.analytics?.average_score||0).toFixed(1)}%`}/><StatCard label='Best Score' value={`${(data.analytics?.best_score||0).toFixed(1)}%`}/><StatCard label='Total Tests' value={data.analytics?.total_tests||0}/></div><div className='glass p-4'><Line data={chartData} options={opts}/></div></>)}</div>)}
