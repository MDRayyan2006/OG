# Quantum Jobs Tracker — Frontend (React + Tailwind + Vite)
Dark, animated dashboard wired for the FastAPI backend.
## Quick Start
```bash
npm install
npm run dev
```
Create `.env` with:
```
VITE_API_BASE_URL=http://localhost:8000
```
